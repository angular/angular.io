describe("Jasmine sample test", function () {

	it("1+1 should be 2", function () {

		var result = 1 + 1;

		expect(result).toBe(2);
	});
});