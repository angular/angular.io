.Class({
  constructor: function () { }
});